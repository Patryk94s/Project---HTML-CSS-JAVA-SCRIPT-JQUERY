
var sum = 0;
var ckbox = $("input[name='vote']");
var chkId;
var b;
var cal;
$(document).ready(function() {
  $('input').on('click', function() {
    if (ckbox.is(':checked')) {
      $("input[name='vote']:checked").each ( function() {
   			chkId = $(this).val();
        b = parseInt(chkId);
 	  });
    }
    sum +=b;
    if(sum<-100){
      $('#ob0').hide()
      $('#ob2').hide()
      $('#ob3').hide()
      $('#ob1').show()
    } else if (sum>100){
      $('#ob0').hide()
      $('#ob1').hide()
      $('#ob3').hide()
      $('#ob2').show()
    } else {
      $('#ob0').hide()
      $('#ob1').hide()
      $('#ob2').hide()
      $('#ob3').show()
    }
  });
});
$(document).ready(function(){
$('#poll2').hide()
$('#poll3').hide()
$('#poll4').hide()
$('#poll5').hide()
$('#poll6').hide()
$('#poll7').hide()
$('#poll8').hide()
$('#poll9').hide()
$('#poll10').hide()
$('#poll11').hide()
$('#ob1').hide()
$('#ob2').hide()
$('#ob3').hide()
});
$("input[type=radio]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').show()
    }
});
$("input[class=pol2]").click(function () {
    if($(this).prop("checked")) {
        $('#poll1').hide()
        $('#poll2').hide()
        $('#poll3').show()
    }
});

$("input[class=pol3]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').show()
    }
});
$("input[class=pol4]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').hide()
      $('#poll5').show()
    }
});
$("input[class=pol5]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').hide()
      $('#poll5').hide()
      $('#poll6').show()
    }
});
$("input[class=pol6]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').hide()
      $('#poll5').hide()
      $('#poll6').hide()
      $('#poll7').show()
    }
});
$("input[class=pol7]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').hide()
      $('#poll5').hide()
      $('#poll6').hide()
      $('#poll7').hide()
      $('#poll8').show()
    }
});
$("input[class=pol8]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').hide()
      $('#poll5').hide()
      $('#poll6').hide()
      $('#poll7').hide()
      $('#poll8').hide()
      $('#poll9').show()
    }
});
$("input[class=pol9]").click(function () {
    if($(this).prop("checked")) {
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').hide()
      $('#poll5').hide()
      $('#poll6').hide()
      $('#poll7').hide()
      $('#poll8').hide()
      $('#poll9').hide()
      $('#poll10').show()
    }
});
$("input[class=pol10]").click(function () {
    if($(this).prop("checked")) {
      $('#poll1').hide()
      $('#poll2').hide()
      $('#poll3').hide()
      $('#poll4').hide()
      $('#poll5').hide()
      $('#poll6').hide()
      $('#poll7').hide()
      $('#poll8').hide()
      $('#poll9').hide()
      $('#poll10').fadeOut(3000)
      $('#poll11').delay(4000).fadeIn("slow")
    }
});
